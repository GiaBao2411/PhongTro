from django.contrib import admin
from django.urls import path
from map_app import views
from django.conf import settings
from django.conf.urls.static import static
from django.contrib.auth import views as auth_views

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # TRANG CHỦ (Vào web là thấy trang giới thiệu)
    path('', views.home, name='home'),
    
    # TRANG BẢN ĐỒ (Bấm menu mới vào đây)
    path('ban-do/', views.map_view, name='map_view'),
    
    # Trang chi tiết
    path('phong-tro/<int:pk>/', views.room_detail, name='room_detail'),
    
    # API
    path('api/tim-kiem/', views.search_api, name='search_api'),
    path('api/dan-duong/', views.route_api, name='route_api'),
    
    # AUTHENTICATION (Đăng nhập/Đăng ký)
    path('dang-ky/', views.register, name='register'),
    path('dang-nhap/', auth_views.LoginView.as_view(template_name='map_app/login.html'), name='login'),
    
    # Đăng xuất xong thì quay về trang chủ (next_page='/')
    path('dang-xuat/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),

    # Thêm dòng này vào (để hứng sự kiện đăng nhập thành công)
    path('login-success/', views.login_success, name='login_success'),

    
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)